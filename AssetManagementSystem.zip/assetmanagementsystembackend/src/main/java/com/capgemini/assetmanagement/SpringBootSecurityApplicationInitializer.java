package com.capgemini.assetmanagement;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringBootSecurityApplicationInitializer extends AbstractSecurityWebApplicationInitializer{

	
}
