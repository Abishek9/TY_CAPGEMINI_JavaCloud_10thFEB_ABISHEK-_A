package com.capgemini.assetmanagement.service;

import java.util.List;


import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.entity.RequestAsset;

public interface RequestAssetService {
	public List<RequestAsset> findAllRequestAsset();

	public RequestAsset save(RequestAsset requestAsset);

	public Page<RequestAsset> getRequestAssets(int pageNo, int itemsPerPage);

	List<RequestAsset> statusData(String status);

	public Page<RequestAsset> getSortRequestAssets(int pageNo, int itemsPerPage, String fieldName);
	
	public RequestAsset addRequest(String email,RequestAsset requestAsset);
	
	public void deleteById(int requestid);
	
	public RequestAsset findAssetById(int requestid);
}
