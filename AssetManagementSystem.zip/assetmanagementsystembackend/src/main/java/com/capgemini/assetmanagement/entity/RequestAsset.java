package com.capgemini.assetmanagement.entity;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@Entity
@Table(name = "requestasset")
@Data
public class RequestAsset {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="request_id")
	private Integer requestId;
	
	
	@NotNull
	@Pattern(regexp ="[0-9]*",
	 message="EmployeeId accepts only alphabets-maximum 10 character")
	@Column(name="employee_id")
	private String employeeId;
	
	
	@NotNull
	@Pattern(regexp ="[0-9]*",
	 message="AssetId accepts only alphabets-maximum 10 character")
	@Column(name="asset_id")
	private String assetId;
	
	
	@NotNull
	@Pattern(regexp ="[0-9]*",
	 message="Quantity accepts only alphabets-maximum 10 character")
	@Column
	private String quantity;
	
	@NotNull
	@Size(max=30, message="Name should have Maximum 30 characters")
	@Column(name="asset_name")
	private String assetName;
	
	@NotNull
	@Size(max=30, message="Name should have Maximum 30 characters")
	@Column
	private String status;
	
	@Column(name="email_id")
	private String emailId; 
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "email")
	@JsonBackReference
	private Users users;

	

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	
	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	
	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "RequestAsset [requestid=" + requestId + ", employeeid=" + employeeId + ", assetid=" + assetId
				+ ", quantity=" + quantity + ", assetname=" + assetName + ", status=" + status + ", emailid=" + emailId
				+ ", users=" + users + "]";
	}

	
	

	

	
	

	
	

	
}
