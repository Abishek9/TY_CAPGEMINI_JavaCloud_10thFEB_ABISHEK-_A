package com.capgemini.assetmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.assetmanagement.entity.Users;

public interface UsersRepository extends JpaRepository<Users, String> {
	
	@Query("from Users where email=?1")
	Users findByEmail(String email);
	
	@Query("from Users where email=?1")
	boolean search(String email);
	
	

	
}
