package com.capgemini.assetmanagement.response;

public class LoginResponse<T> {

	private boolean error;
	
	private String message;
	
	private String token;
	
	T data;
	
	public LoginResponse() {
		
	}

	
	
	public LoginResponse(boolean error, String message, String token, T data) {
		super();
		this.error = error;
		this.message = message;
		this.token = token;
		this.data = data;
	}



	public boolean isError() {
		return error;
	}



	public void setError(boolean error) {
		this.error = error;
	}



	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public String getToken() {
		return token;
	}



	public void setToken(String token) {
		this.token = token;
	}



	public T getData() {
		return data;
	}



	public void setData(T data) {
		this.data = data;
	}



	@Override
	public String toString() {
		return "loginResponse [error=" + error + ", message=" + message + ", token=" + token + ", data=" + data + "]";
	}
	
	
}
