package com.capgemini.assetmanagement.rest;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.Users;
import com.capgemini.assetmanagement.exception.EmailNotFoundException;
import com.capgemini.assetmanagement.exception.UsersNotFoundException;
import com.capgemini.assetmanagement.response.LoginResponse;
import com.capgemini.assetmanagement.response.Response;
import com.capgemini.assetmanagement.service.JwtUtil;
import com.capgemini.assetmanagement.service.UsersService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class UsersRestController {
private UsersService usersService;
	
	

	@Autowired
	public UsersRestController(UsersService theUsersService) {
		usersService = theUsersService;
	}
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtil jwtUtil; 
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	
//	@PostMapping("/login")
//	public ResponseEntity<?> login(@RequestBody Users register) throws Exception{
//	
//		try {
//			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(register.getEmail(),register.getPassword()));
//		} catch(DisabledException de) {
//			//we should use loggers here
//			System.out.println("User is Disabled");
//			throw new Exception("USER_DISABLED",de);
//			
//		} catch(BadCredentialsException bce) {
//			//we should  use loggers here
//			throw new Exception("INVALID_CREDENTIALS", bce);
//		
//		}// End of try catch
//		
//		final UserDetails userDetails = userDetailsService.loadUserByUsername(register.getEmail());
//	
//		final String jwt = jwtUtil.generateToken(userDetails);
//		
//		return ResponseEntity.ok(new JwtResponse(jwt));//doubt
//	}// End of login()
//	
	@PostMapping("/login")
	public LoginResponse<Users> login(@RequestBody Users register) throws Exception{
	
		Users use = usersService.findByEmail(register.getEmail());
		if (use == null) {
			return new LoginResponse<>(true, "Invalid Credentials", null, null);
			}

		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(register.getEmail(),register.getPassword()));
		} catch(DisabledException de) {
			//we should use loggers here
			throw new EmailNotFoundException("Invalid Credentials");
			
		} catch(BadCredentialsException bce) {
			//we should  use loggers here
			throw new EmailNotFoundException("Invalid Credentials");
			
		
		}// End of try catch
		
		final UserDetails userDetails = userDetailsService.loadUserByUsername(register.getEmail());
	
		final String jwt = jwtUtil.generateToken(userDetails);
		
		return new LoginResponse<Users>(false,"Login Successfull",jwt,use);
	}// End of login()
	
	
	@GetMapping("/getAllUsersu")
	public List<Users> findAllUserss() {

		return usersService.findAllUsers();
	}
	
	@GetMapping("/getAllUsersa")
	public List<Users> findAllUser() {

		return usersService.findAllUsers();
	}
	
	@GetMapping("/users/{email}")
	public Response<Users> getStudent(@PathVariable String email) {

		Users users = usersService.findUsersById(email);

		if (users != null) {
			return new Response<>(false,"email found",users);
			
		}else
		{
			throw new UsersNotFoundException("email not found");
		}
	}
	
	@PostMapping("/addusers")
	public Response<Users> addUsers(@RequestBody Users users) {
		boolean reg = usersService.search(users.getEmail());
//		users.setUserId(0);
		users.setRole("ROLE_USER");
		if(reg != true) {
			Users users1 = usersService.save(users);
			if(users1!= null) {
				return new Response<Users>(false,"User added successfully", users1);
			}else {
				throw new UsersNotFoundException("User not Added");
			}
		}
		else {
			return new Response<Users>(true,"User already exist", users);
		}
		 
	}
	
//	@PutMapping("/updateusers")
//	public Response<Users> updateAsset(@RequestBody Users users) {
//
//		Users asset2 = usersService.save(users);
//		if(asset2!= null) {
//			return new Response<Users>(false,"Updated", users);
//		}else {
//			return new Response<Users>(true,"Not updated", null);
//		}
//
//	}
	
	@GetMapping("/getS/{email}")
	public Response<Users> getUser(@PathVariable String email) {
		Users register = usersService.findById(email);
		
		if (register != null) {
			return new Response<Users>(false, "email found", register);
		} else {
			throw new UsersNotFoundException("email not found for " + email);
		}
		 
	}
	
	@PutMapping("/updateUser")
	public Response<Users> updateUser(@RequestBody Users users) {
		users.setRole("ROLE_USER");

		Users users2 = usersService.update(users);
		if(users2 != null) {
			return new Response<Users>(false, "User details updated successfully", users2);
		} else {
			throw new UsersNotFoundException("User Not found");
		}

	}
	
	@DeleteMapping("/deleteusers/{email}")
	public Response<Users> deleteUser(@PathVariable String email) {

		Users users3 = usersService.findUsersById(email);

		// throw exception if null
		if (users3 != null) {
			usersService.deleteById(email);
			return new Response<Users>(false,"User deleted successfully",users3);
		}else {
			throw new UsersNotFoundException("User not found" + email);
		}
}
	
	@GetMapping("/users/{pageNo}/{itemsPerPage}")
	public Page<Users> getAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage){
		return usersService.getUsers(pageNo,itemsPerPage);
	}
	
	@GetMapping("/users/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<Users> getSortAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage,@PathVariable	 String fieldName){
		return usersService.getSortUsers(pageNo,itemsPerPage,fieldName);
	}
	
	
}
