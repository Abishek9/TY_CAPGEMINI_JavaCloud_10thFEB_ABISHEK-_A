package com.capgemini.assetmanagement.exception;

public class RequestAssetNotFoundException extends RuntimeException {
	public RequestAssetNotFoundException(String message ) {
		super(message);
	}
}
