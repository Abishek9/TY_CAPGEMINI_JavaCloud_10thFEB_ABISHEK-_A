package com.capgemini.assetmanagement.entity;

import javax.persistence.Column;

	
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Entity
@Table(name = "assets")
@Data
public class Asset {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="asset_id")
	private Integer assetId;

	@Column
	@NotNull
	@Pattern(regexp = "[a-zA-Z]*",
	 message="Title accepts only alphabets-maximum 20 character")
	private String title;

	@Column
	@NotNull
	@Pattern(regexp = "[a-zA-Z]*",
	 message="Category accepts only alphabets-maximum 20 character")
	private String category;
	
	@Column

	@NotNull
	@Pattern(regexp ="[0-9]*",
	 message="Quantity accepts only alphabets-maximum 10 character")
	private String quantity;
	

	@NotNull
	@Pattern(regexp ="[0-9]*",
	 message="Price accepts only numbers-maximum 10 character")
	@Column
	private String price;
	

	@NotNull
	@Column
	private String details;

	
	public Integer getAssetId() {
		return assetId;
	}

	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "Asset [assetid=" + assetId + ", title=" + title + ", category=" + category + ", quantity=" + quantity
				+ ", price=" + price +  ", details=" + details + "]";
	}

	
	
	
}
