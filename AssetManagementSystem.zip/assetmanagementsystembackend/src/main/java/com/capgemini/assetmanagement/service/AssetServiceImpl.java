 package com.capgemini.assetmanagement.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.assetmanagement.dao.AssetRepository;
import com.capgemini.assetmanagement.entity.Asset;




@Service
public class AssetServiceImpl implements AssetService {

	private AssetRepository assetRepository;

	@Autowired
	public AssetServiceImpl(AssetRepository theassetRepository) {
		assetRepository = theassetRepository;
	}

	@Override
	public List<Asset> findAllAssets() {

		return assetRepository.findAll();
	}

	@Override
	public Asset findAssetById(int assetid) {

		Optional<Asset> result = assetRepository.findById(assetid);
	
		if (result.isPresent()) {
			Asset asset1 = result.get();
			return asset1;
		} 
		return null;
	}

	@Override
	public Asset save(Asset asset) {
		return assetRepository.save(asset);
	}

	@Override
	public void deleteById(int assetid) {
		assetRepository.deleteById(assetid);
	}

	@Override
	public Page<Asset> getAssets(int pageNo, int itemsPerPage) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage);
		return assetRepository.findAll(pageable);
	}

	@Override
	public Page<Asset> getSortAssets(int pageNo, int itemsPerPage, String fieldName) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage,Sort.by(fieldName));
		return assetRepository.findAll(pageable);
	}

}
