package com.capgemini.assetmanagement.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.assetmanagement.dao.RequestAssetRepository;
import com.capgemini.assetmanagement.dao.UsersRepository;
import com.capgemini.assetmanagement.entity.RequestAsset;
import com.capgemini.assetmanagement.entity.Users;

@Service
public class RequestAssetServiceImpl implements RequestAssetService {

	private RequestAssetRepository requestAssetRepository;
	
	private UsersRepository userrepository;

	@Autowired
	public RequestAssetServiceImpl(RequestAssetRepository therequestAssetRepository,UsersRepository theuserRepository) {
		requestAssetRepository = therequestAssetRepository;
		userrepository = theuserRepository;
	}
	
	@Override
	public List<RequestAsset> findAllRequestAsset() {
		return requestAssetRepository.findAll();
	}

	@Override
	public RequestAsset save(RequestAsset requestAsset) {
		return requestAssetRepository.save(requestAsset);
	}
	
	@Override
	public List<RequestAsset> statusData(String status) {
		return requestAssetRepository.statusData(status);
	}


	@Override
	public Page<RequestAsset> getRequestAssets(int pageNo, int itemsPerPage) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage);
		return requestAssetRepository.findAll(pageable);
	}

	@Override
	public Page<RequestAsset> getSortRequestAssets(int pageNo, int itemsPerPage, String fieldName) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage,Sort.by(fieldName));
		return requestAssetRepository.findAll(pageable);
	}
	@Override
	public RequestAsset addRequest(String email, RequestAsset requestAsset) {
		Users user = userrepository.findById(email).get();
		if(user != null) {
			requestAsset.setEmailId(user.getEmail());
			requestAsset.setUsers(user);
		}
		return requestAssetRepository.save(requestAsset);
	}
	
	@Override
	public void deleteById(int requestid) {
		requestAssetRepository.deleteById(requestid);
	}
	
	@Override
	public RequestAsset findAssetById(int requestid) {

		Optional<RequestAsset> result = requestAssetRepository.findById(requestid);
	
		if (result.isPresent()) {
			RequestAsset asset2 = result.get();
			return asset2;
		} 
		return null;
	}
	
	

}
