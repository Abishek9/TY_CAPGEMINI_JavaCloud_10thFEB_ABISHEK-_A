package com.capgemini.assetmanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Entity
@Table(name = "user")
@Data
public class Users {

	@Id
	@Column
	@Pattern(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$",
	 message="Invalid emailId")
	private String email;
	
	@NotNull
	@Size(max=30, message="Name should have Maximum 30 characters")
	@Pattern(regexp = "[a-zA-Z]*",
	 message="Name accepts only alphabets-maximum 20 character")
	@Column(name="first_name")
	private String firstName;
	
	@NotNull
	@Size(max=30, message="Name should have Maximum 30 characters")
	@Pattern(regexp = "[a-zA-Z]*",
	 message="Name accepts only alphabets-maximum 20 character")
	@Column(name="last_name")
	private String lastName;
	
	@NotNull
	@Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&].{8,}",
	 message="Password should contain atleast 8 characters-one lowercase-one uppercase-numbers-specialcharacters")
	@Column
	private String password;
	
//	@NotNull
	@Size(max=30, message="Role  should have Maximum 30 characters")
	@Column
	private String role;
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_id")
	private int userId;
	
	@OneToMany(mappedBy = "users",cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<RequestAsset> requestAsset;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	
	public List<RequestAsset> getRequestAsset() {
		return requestAsset;
	}

	public void setRequestAsset(List<RequestAsset> requestAsset) {
		this.requestAsset = requestAsset;
	}
	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Users [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", password="
				+ password + ", role=" + role + ", userId=" + userId + ", requestAsset=" + requestAsset + "]";
	}

	

	
	
	
}
