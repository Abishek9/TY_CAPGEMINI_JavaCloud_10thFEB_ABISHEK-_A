package com.capgemini.assetmanagement.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.capgemini.assetmanagement.dao.UsersRepository;
import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.Users;

@Service
public class UsersServiceImpl implements UsersService {

	private UsersRepository usersRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	public UsersServiceImpl(UsersRepository theusersRepository) {
		usersRepository = theusersRepository;
	}
	@Override
	public List<Users> findAllUsers() {
		return usersRepository.findAll();
		
	}

	@Override
	public Users findUsersById(String email) {
		Optional<Users> result = usersRepository.findById(email);
		
		if (result.isPresent()) {
			Users users1 = result.get();
			return users1;
		} 
		return null;
	}
	
	@Override
	public Users findById(String email) {
		Optional<Users> result = usersRepository.findById(email);
		
		Users register;
		if (result.isPresent()) {
			register = result.get();
		} else {
			throw new RuntimeException("email not found " + email);
		}
		return register;
	}
	
	@Override
	public Users findByEmail(String email) {
		
		Users register = usersRepository.findByEmail(email);
		return register;
	}

	@Override
	public Users save(Users users) {
		users.setPassword(passwordEncoder.encode(users.getPassword()));
		return usersRepository.save(users);
	}
	
	@Override
	public Users update(Users users) {

		return usersRepository.save(users);

	}
	
	@Override
	public void deleteById(String email) {
		usersRepository.deleteById(email);
	}
	
	@Override
	public boolean search(String email) {
		boolean result = usersRepository.existsById(email);
		return result;
	}
	
	@Override
	public Page<Users> getUsers(int pageNo, int itemsPerPage) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage);
		return usersRepository.findAll(pageable);
	}

	@Override
	public Page<Users> getSortUsers(int pageNo, int itemsPerPage, String fieldName) {
		Pageable pageable = PageRequest.of(pageNo,itemsPerPage,Sort.by(fieldName));
		return usersRepository.findAll(pageable);
	}

}
