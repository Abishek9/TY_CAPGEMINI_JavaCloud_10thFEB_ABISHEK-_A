package com.capgemini.assetmanagement.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.assetmanagement.entity.Asset;

public interface AssetPaginationRepository extends PagingAndSortingRepository<Asset,Integer>{

}
