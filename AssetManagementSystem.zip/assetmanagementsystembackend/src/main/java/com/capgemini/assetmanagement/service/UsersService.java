package com.capgemini.assetmanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.Users;

public interface UsersService {

	public List<Users> findAllUsers();

	public Users findUsersById(String email);

	public Users save(Users users);
	
	Users findByEmail(String email);
	
	public Users findById(String email);
	
	public void deleteById(String email);
	
	public boolean search(String email);
	
	public Page<Users> getUsers(int pageNo, int itemsPerPage);
	
	public Page<Users> getSortUsers(int pageNo, int itemsPerPage,String fieldName );
	
	public Users update(Users users);
	
	
	
	
	
}
