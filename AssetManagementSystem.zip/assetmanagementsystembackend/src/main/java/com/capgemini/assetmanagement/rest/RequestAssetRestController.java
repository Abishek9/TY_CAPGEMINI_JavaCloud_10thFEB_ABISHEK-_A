package com.capgemini.assetmanagement.rest;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.entity.RequestAsset;
import com.capgemini.assetmanagement.exception.RequestAssetNotFoundException;
import com.capgemini.assetmanagement.response.Response;
import com.capgemini.assetmanagement.service.RequestAssetService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class RequestAssetRestController {
	private RequestAssetService requestAssetService; 

	@Autowired
	public RequestAssetRestController(RequestAssetService theRequestAssetService) {
		requestAssetService = theRequestAssetService;
	}
	
	@PostMapping("/sendrequestassets")
	public Response<RequestAsset> addRequestAsset(@RequestBody RequestAsset requestAsset) {

		RequestAsset asset1 = requestAssetService.save(requestAsset);
		if(asset1!= null) {
			return new Response<RequestAsset>(false,"Request sent to the admin", requestAsset);
		}else {
			return new Response<RequestAsset>(true,"Rwequest not sent", null);
		}
		 
	}
	
	@GetMapping("/getallrequestassets")
	public List<RequestAsset> findAllRequestAssets() {

		return requestAssetService.findAllRequestAsset();
	}

	@PutMapping("/updaterequestassets")
	public Response<RequestAsset> updateRequestAsset(@RequestBody RequestAsset requestAsset) {

		RequestAsset requestAsset3 = requestAssetService.save(requestAsset);
		if(requestAsset3!= null) {
			return new Response<RequestAsset>(false,"Updated", requestAsset);
		}else {
			return new Response<RequestAsset>(true,"Not updated", null);
		}

	}
	
	@PostMapping("/addrequest/{email}")
	public Response<RequestAsset> addRequest(@PathVariable String email,@RequestBody RequestAsset requestAsset) {

		RequestAsset asset2 = requestAssetService.addRequest(email,requestAsset);
		if(asset2!= null) {
			return new Response<RequestAsset>(false,"Request sent to the admin", requestAsset);
		}else {
			return new Response<RequestAsset>(true,"Request not sent", null);
		}
		 
	}
	
	@PutMapping("/updaterequest/{email}")
	public Response<RequestAsset> updateRequests(@PathVariable String email, @RequestBody RequestAsset theRequest) {
		RequestAsset request = requestAssetService.addRequest(email,theRequest);
		if(request != null) {
			return new Response<RequestAsset>(false, "Request updated", request);
		} else {
			throw new RequestAssetNotFoundException(" Request not updated");
		}
	}
	
	
	@GetMapping("/get/{status}")
	public List<RequestAsset> getUser(@PathVariable String status) {
		return  requestAssetService.statusData(status);
		
	}
	
	@GetMapping("/requestassets/{pageNo}/{itemsPerPage}")
	public Page<RequestAsset> getAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage){
		return requestAssetService.getRequestAssets(pageNo,itemsPerPage);
	}
	
	@GetMapping("/requestassets/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<RequestAsset> getSortAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage,@PathVariable	 String fieldName){
		return requestAssetService.getSortRequestAssets(pageNo,itemsPerPage,fieldName);
	}
}
