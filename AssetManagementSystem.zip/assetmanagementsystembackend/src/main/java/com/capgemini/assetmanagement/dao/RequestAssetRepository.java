package com.capgemini.assetmanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.assetmanagement.entity.RequestAsset;

public interface RequestAssetRepository  extends JpaRepository<RequestAsset, Integer> {

	@Query("from RequestAsset where status=?1")
	List<RequestAsset> statusData(String status);
}
