package com.capgemini.assetmanagement.rest;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.exception.AssetNotFoundException;
import com.capgemini.assetmanagement.response.Response;
import com.capgemini.assetmanagement.service.AssetService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class AssetRestController {

	private AssetService assetService;
	

	@Autowired
	public AssetRestController(AssetService theassetService) {
		assetService = theassetService;
		
	}

	// expose "/students" to return list of students
	@GetMapping("/assets")
	public List<Asset> findAllAssets() {

		return assetService.findAllAssets();
	}

	// add mapping for GET /students/{studentId}
	@GetMapping("/assets/{assetId}")
	public Response<Asset> getStudent(@PathVariable int assetId) {

		Asset asset = assetService.findAssetById(assetId);

		if (asset != null) {
			return new Response<>(false,"records found",asset);
			
		}else
		{
			throw new AssetNotFoundException("record not found");
		}
	}

	// add mapping for POST /students - add new student
	@PostMapping("/addassets")
	public Response<Asset> addAsset(@Valid @RequestBody Asset asset) {

		// also just in case they pass an id in JSON .... set id to 0
		// this is to force a save of new item .... instead of update
//		asset.setAssetid(0);

		Asset asset1 = assetService.save(asset);
		if(asset1!= null) {
			return new Response<Asset>(false,"successfully saved", asset1);
		}else {
			return new Response<Asset>(true,"save failed", null);
		}
		 
	}

	// add mapping for PUT /students - update student
	@PutMapping("/assets")
	public Response<Asset> updateAsset(@RequestBody Asset asset) {

		Asset asset2 = assetService.save(asset);
		if(asset2!= null) {
			return new Response<Asset>(false,"Updated", asset);
		}else {
			return new Response<Asset>(true,"Not updated", null);
		}

	}

	// add mapping for DELETE /students/{studentId} - delete student
	@DeleteMapping("/assets/{assetId}")
	public Integer deleteAsset(@PathVariable int assetId) {

		Asset theAsset = assetService.findAssetById(assetId);

		// throw exception if null
		if (theAsset == null) {
			throw new RuntimeException("User Id not found:" + assetId);
		}
		assetService.deleteById(assetId);

		return  assetId;

	}
	
	@GetMapping("/assets/{pageNo}/{itemsPerPage}")
	public Page<Asset> getAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage){
		return assetService.getAssets(pageNo,itemsPerPage);
	}
	
	@GetMapping("/assets/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<Asset> getSortAssets(@PathVariable int pageNo,@PathVariable int itemsPerPage,@PathVariable	 String fieldName){
		return assetService.getSortAssets(pageNo,itemsPerPage,fieldName);
	}
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
