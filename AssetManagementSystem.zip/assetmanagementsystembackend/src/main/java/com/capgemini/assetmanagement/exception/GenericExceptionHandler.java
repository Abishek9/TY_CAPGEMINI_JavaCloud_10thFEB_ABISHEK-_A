package com.capgemini.assetmanagement.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.RequestAsset;
import com.capgemini.assetmanagement.entity.Users;
import com.capgemini.assetmanagement.response.LoginResponse;
import com.capgemini.assetmanagement.response.Response;

@ControllerAdvice
public class GenericExceptionHandler {

	@ExceptionHandler 
	public ResponseEntity<Response<Asset>> handleException(AssetNotFoundException ex){
		Response<Asset> response = new Response<Asset>(true,ex.getMessage(),null); 
		return new ResponseEntity<Response<Asset>>(response,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler 
	public ResponseEntity<Response<RequestAsset>> handleException1(RequestAssetNotFoundException ex){
		Response<RequestAsset> response = new Response<RequestAsset>(true,ex.getMessage(),null); 
		return new ResponseEntity<Response<RequestAsset>>(response,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler 
	public ResponseEntity<Response<Users>> handleException2(UsersNotFoundException ex){
		Response<Users> response = new Response<Users>(true,ex.getMessage(),null); 
		return new ResponseEntity<Response<Users>>(response,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler
	public ResponseEntity<LoginResponse<Users>> handleException(EmailNotFoundException exception) {

		LoginResponse<Users> response = new LoginResponse<>(true, exception.getMessage(), null,null);

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

}
