package com.capgemini.assetmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.assetmanagement.entity.Asset;


public interface AssetRepository extends JpaRepository<Asset, Integer> {
	
	// no need to write code
}
