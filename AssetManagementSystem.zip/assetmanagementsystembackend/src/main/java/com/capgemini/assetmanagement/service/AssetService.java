package com.capgemini.assetmanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.entity.Asset;


public interface AssetService {

	public List<Asset> findAllAssets();

	public Asset findAssetById(int assetid);

	public Asset save(Asset asset);

	public void deleteById(int assetid);
	
	public Page<Asset> getAssets(int pageNo, int itemsPerPage);
	
	public Page<Asset> getSortAssets(int pageNo, int itemsPerPage,String fieldName );
}
