package com.capgemini.springboot.cruddemo.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.assetmanagement.entity.Users;
import com.capgemini.assetmanagement.service.UsersService;

@SpringBootTest
class UsersServiceImplTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	@Autowired
	private UsersService userService;
	
	Users user;
	
	Users userData =null;
	
	@BeforeEach
	void registerUser() {
		
		user = new Users();
		user.setEmail("abishek@gmail.com");
		user.setFirstName("Abishek");
		user.setLastName("A");
		user.setPassword("Abishek@123");
		user.setRole("ROLE_USER");
		
		userData = userService.save(user);
		
	}
	
	@Test 
	void testSave() {
		assertNotNull(userData);
	}
	
	@Test
	void testFindById() {
		Users reg = userService.findById("abishek@gmail.com");
		assertNotNull(reg);
	
	}
	
	@Test
	void testFindAll() {
		
		List<Users> registerList = userService.findAllUsers();
		assertNotNull(registerList);
	}
	
	
	@AfterEach
	void testDeleteUser() {
		userService.deleteById(user.getEmail());
	}

}
