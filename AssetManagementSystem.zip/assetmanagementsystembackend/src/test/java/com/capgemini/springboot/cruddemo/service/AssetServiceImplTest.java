package com.capgemini.springboot.cruddemo.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.Users;
import com.capgemini.assetmanagement.service.AssetService;

@SpringBootTest
class AssetServiceImplTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}

	@Autowired
	private AssetService assetService;
	
	Asset asset;
	
	Asset assetData =null;
	
	@BeforeEach
	void registerUser() {
		
		asset = new Asset();
		asset.setCategory("Samsung");
		asset.setTitle("Phone");
		asset.setPrice("30000");
		asset.setQuantity("2");
		asset.setDetails("Good One");
		
		assetData = assetService.save(asset);
		
	}
	
	@Test 
	void testSave() {
		assertNotNull(assetData);
	}
	
	@Test
	void testFindById() {
		Asset reg = assetService.findAssetById(assetData.getAssetId());
		assertNotNull(reg);
	
	}
	
	@Test
	void testFindAll() {
		
		List<Asset> registerList = assetService.findAllAssets();
		assertNotNull(registerList);
	}
	
	
	@AfterEach
	void testDeleteUser() {
		assetService.deleteById(assetData.getAssetId());
	}

}

