package com.capgemini.springboot.cruddemo.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.assetmanagement.entity.Asset;
import com.capgemini.assetmanagement.entity.RequestAsset;
import com.capgemini.assetmanagement.service.RequestAssetService;

@SpringBootTest
class RequestAssetServiceImplTest {
	@Autowired
	private RequestAssetService requestAssetService;
	
	RequestAsset requestasset;
	
	RequestAsset requestAssetData =null;
	
	@BeforeEach
	void registerUser() {
		
		requestasset = new RequestAsset();
		requestasset.setAssetId("1023");
		requestasset.setEmployeeId("1023");
		requestasset.setAssetName("Phone");
		requestasset.setQuantity("2");
		requestasset.setStatus("Pending");
		requestasset.setEmailId("Abishek@gmail.com");
		
		requestAssetData = requestAssetService.save(requestasset);
		
	}
	
	@Test 
	void testSave() {
		assertNotNull(requestAssetData);
	}
	
	@Test
	void testFindById() {
		RequestAsset reg = requestAssetService.findAssetById(requestAssetData.getRequestId());
	
	}
	
	@Test
	void testFindAll() {
		
		List<RequestAsset> registerList = requestAssetService.findAllRequestAsset();
		assertNotNull(registerList);
	}
	
	
	@AfterEach
	void testDeleteUser() {
		requestAssetService.deleteById(requestAssetData.getRequestId());
	}

	

}
